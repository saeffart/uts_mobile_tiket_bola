package com.example.halaman_utama;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.NumberFormat;
import java.util.Locale;

public class MainActivity3 extends AppCompatActivity {

    TextView tvMatchHeader, tvTotalBayar;
    RadioGroup rgPaket;
    EditText etJumlahTiket;
    Button btnProses;

    int hargaTiket = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inisialisasi
        tvMatchHeader = findViewById(R.id.tvMatchHeader);
        tvTotalBayar = findViewById(R.id.tvTotalBayar);
        rgPaket = findViewById(R.id.rgPaket);
        etJumlahTiket = findViewById(R.id.etJumlahTiket);
        btnProses = findViewById(R.id.btnProses);

        // Ambil data dari Intent (jika ada)
        String matchName = getIntent().getStringExtra("MATCH_NAME");
        if (matchName != null) {
            tvMatchHeader.setText(matchName);
        }

        // Listener pilihan tiket
        rgPaket.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.rbReguler) {
                hargaTiket = 150000;
            } else if (checkedId == R.id.rbVIP_Barat) {
                hargaTiket = 500000;
            } else if (checkedId == R.id.rbVVIP) {
                hargaTiket = 1500000;
            }

            hitungTotal();
        });

        // Auto hitung saat input berubah
        etJumlahTiket.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                hitungTotal();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        btnProses.setOnClickListener(v -> {

            if (rgPaket.getCheckedRadioButtonId() == -1) {
                Toast.makeText(this, "Pilih kategori tiket!", Toast.LENGTH_SHORT).show();
                return;
            }

            String jumlahStr = etJumlahTiket.getText().toString();
            if (jumlahStr.isEmpty()) {
                Toast.makeText(this, "Masukkan jumlah tiket!", Toast.LENGTH_SHORT).show();
                return;
            }

            int jumlah = Integer.parseInt(jumlahStr);
            int total = jumlah * hargaTiket;

            String rupiah = NumberFormat
                    .getCurrencyInstance(new Locale("in", "ID"))
                    .format(total);

            Toast.makeText(this,
                    "Pembayaran Berhasil!\nTotal: " + rupiah,
                    Toast.LENGTH_LONG).show();
        });
    }

    private void hitungTotal() {
        String jumlahStr = etJumlahTiket.getText().toString();

        if (!jumlahStr.isEmpty() && hargaTiket > 0) {
            int jumlah = Integer.parseInt(jumlahStr);
            int total = jumlah * hargaTiket;

            String rupiah = NumberFormat
                    .getCurrencyInstance(new Locale("in", "ID"))
                    .format(total);

            tvTotalBayar.setText(rupiah);
        } else {
            tvTotalBayar.setText("Rp 0");
        }
    }
}