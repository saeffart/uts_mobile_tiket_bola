package com.example.halaman_utama;

import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity4 extends AppCompatActivity {

    TextView tvMatch, tvPaket, tvJumlah, tvTotal;
    RadioGroup rgPayment;
    Button btnBayar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inisialisasi
        tvMatch = findViewById(R.id.tvSummaryMatch);
        tvPaket = findViewById(R.id.tvSummaryPaket);
        tvJumlah = findViewById(R.id.tvSummaryJumlah);
        tvTotal = findViewById(R.id.tvSummaryTotal);

        rgPayment = findViewById(R.id.rgPaymentMethod);
        btnBayar = findViewById(R.id.btnPayNow);

        // Ambil data dari Intent (dari halaman sebelumnya)
        String match = getIntent().getStringExtra("MATCH_NAME");
        String paket = getIntent().getStringExtra("PAKET");
        int jumlah = getIntent().getIntExtra("JUMLAH", 0);
        String total = getIntent().getStringExtra("TOTAL");

        // Set ke tampilan
        if (match != null) tvMatch.setText(match);
        if (paket != null) tvPaket.setText("Kategori: " + paket);
        tvJumlah.setText("Jumlah: " + jumlah + " Tiket");
        if (total != null) tvTotal.setText(total);

        // Tombol bayar
        btnBayar.setOnClickListener(v -> {

            if (rgPayment.getCheckedRadioButtonId() == -1) {
                Toast.makeText(this, "Pilih metode pembayaran!", Toast.LENGTH_SHORT).show();
                return;
            }

            String metode = "";

            int selectedId = rgPayment.getCheckedRadioButtonId();
            if (selectedId == R.id.rbBankTransfer) {
                metode = "Transfer Bank";
            } else if (selectedId == R.id.rbEWallet) {
                metode = "E-Wallet";
            } else if (selectedId == R.id.rbCreditCard) {
                metode = "Kartu Kredit/Debit";
            }

            Toast.makeText(this,
                    "Pembayaran Berhasil!\nMetode: " + metode,
                    Toast.LENGTH_LONG).show();
        });
    }
}