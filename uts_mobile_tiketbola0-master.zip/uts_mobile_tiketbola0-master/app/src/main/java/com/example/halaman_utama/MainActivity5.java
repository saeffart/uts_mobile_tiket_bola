package com.example.halaman_utama;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity5 extends AppCompatActivity {

    TextView tvMatch, tvKategori;
    Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inisialisasi
        tvMatch = findViewById(R.id.tvTicketMatch);
        tvKategori = findViewById(R.id.tvTicketPaket);
        btnBack = findViewById(R.id.btnBackToHome);

        // Ambil data dari Intent (jika ada)
        Intent intent = getIntent();

        String match = intent.getStringExtra("MATCH");
        String kategori = intent.getStringExtra("KATEGORI");

        // Set data ke tampilan (jika tidak null)
        if (match != null) {
            tvMatch.setText(match);
        }

        if (kategori != null) {
            tvKategori.setText(kategori);
        }

        // Tombol kembali ke beranda
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Pindah ke HomeActivity (buat kalau belum ada)
                Intent intent = new Intent(MainActivity5.this,MainActivity.class);
                startActivity(intent);

                // Tutup activity sekarang
                finish();
            }
        });
    }
}