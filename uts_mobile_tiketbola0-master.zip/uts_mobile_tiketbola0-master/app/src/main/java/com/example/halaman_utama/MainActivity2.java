package com.example.halaman_utama;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.NumberFormat;
import java.util.Locale;

public class MainActivity2 extends AppCompatActivity {

    TextView tvMatchHeader, tvTotalBayar;
    RadioGroup rgPaket;
    RadioButton rbReguler, rbVIP, rbVVIP;
    EditText etJumlah;
    Button btnProses;

    int hargaTiket = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        // Inisialisasi
        tvMatchHeader = findViewById(R.id.tvMatchHeader);
        tvTotalBayar = findViewById(R.id.tvTotalBayar);
        rgPaket = findViewById(R.id.rgPaket);
        rbReguler = findViewById(R.id.rbReguler);
        rbVIP = findViewById(R.id.rbVIP_Barat);
        rbVVIP = findViewById(R.id.rbVVIP);
        etJumlah = findViewById(R.id.etJumlahTiket);
        btnProses = findViewById(R.id.btnProses);

        // Ambil data dari MainActivity
        String matchName = getIntent().getStringExtra("MATCH_NAME");
        if (matchName != null) {
            tvMatchHeader.setText(matchName);
        }

        // Listener pilihan paket
        rgPaket.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.rbReguler) {
                hargaTiket = 150000;
            } else if (checkedId == R.id.rbVIP_Barat) {
                hargaTiket = 500000;
            } else if (checkedId == R.id.rbVVIP) {
                hargaTiket = 1500000;
            }

            hitungTotal();
        });

        // Saat tombol ditekan
        btnProses.setOnClickListener(v -> {

            String jumlahStr = etJumlah.getText().toString();

            if (rgPaket.getCheckedRadioButtonId() == -1) {
                Toast.makeText(this, "Pilih kategori tiket!", Toast.LENGTH_SHORT).show();
                return;
            }

            if (jumlahStr.isEmpty()) {
                Toast.makeText(this, "Masukkan jumlah tiket!", Toast.LENGTH_SHORT).show();
                return;
            }

            int jumlah = Integer.parseInt(jumlahStr);
            int total = jumlah * hargaTiket;

            String formatRupiah = NumberFormat
                    .getCurrencyInstance(new Locale("in", "ID"))
                    .format(total);

            Toast.makeText(this,
                    "Pembayaran Berhasil!\nTotal: " + formatRupiah,
                    Toast.LENGTH_LONG).show();
        });
    }

    private void hitungTotal() {
        String jumlahStr = etJumlah.getText().toString();

        if (!jumlahStr.isEmpty()) {
            int jumlah = Integer.parseInt(jumlahStr);
            int total = jumlah * hargaTiket;

            String formatRupiah = NumberFormat
                    .getCurrencyInstance(new Locale("in", "ID"))
                    .format(total);

            tvTotalBayar.setText(formatRupiah);
        }
    }
}