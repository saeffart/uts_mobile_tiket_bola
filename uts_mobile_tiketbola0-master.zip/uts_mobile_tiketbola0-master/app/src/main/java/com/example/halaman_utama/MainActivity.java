package com.example.halaman_utama;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button btnBeli1, btnBeli2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inisialisasi tombol
        btnBeli1 = findViewById(R.id.btnbeli);
        btnBeli2 = findViewById(R.id.btntiket);

        // EVENT MATCH 1 (Persija vs Persib)
        btnBeli1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(MainActivity.this,
                        "Memesan tiket Persija vs Persib",
                        Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                intent.putExtra("MATCH_NAME", "Persija vs Persib");
                intent.putExtra("MATCH_VENUE", "Stadion GBK");
                intent.putExtra("MATCH_TIME", "20 Mei 2026 | 19:00 WIB");
                startActivity(intent);
            }
        });

        // EVENT MATCH 2 (Arema vs Persebaya)
        btnBeli2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(MainActivity.this,
                        "Memesan tiket Arema vs Persebaya",
                        Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(MainActivity.this, MainActivity3.class);
                intent.putExtra("MATCH_NAME", "Arema vs Persebaya");
                intent.putExtra("MATCH_VENUE", "Stadion Kanjuruhan");
                intent.putExtra("MATCH_TIME", "25 Mei 2026 | 15:30 WIB");
                startActivity(intent);
            }
        });
    }
}